###############################################################################
## Author: Team Supply Bot
## Edition: eYRC 2019-20
## Instructions: Do Not modify the basic skeletal structure of given APIs!!!
###############################################################################


######################
## Essential libraries
######################
import cv2 as cv
import numpy as np
import os
import math
import csv




########################################################################
## using os to generalise Input-Output
########################################################################
codes_folder_path = os.path.abspath('.')
images_folder_path = os.path.abspath(os.path.join('..', 'Images'))
generated_folder_path = os.path.abspath(os.path.join('..', 'Generated'))




############################################
## Build your algorithm in this function
## ip_image: is the array of the input image
## imshow helps you view that you have loaded
## the corresponding image
############################################
def process(ip_image):
############################################
## Main Process
## What has been done?
##  Convert Image to grey scale
##  Apply Blur so that circle detection can be easy
##  Detect Circles (Parameters set based on heavy Trail and Error)
##  Create a new mask image and draw a circle on in with parametes detected in above process
##  bitwise_and both mask and original Image
##  Convert image into greyscale
##  apply threshold to remove left over colours.
##  return Processed Image
############################################
    outerRadius = 0
    innerRadius = 0
    Center = []
    img = ip_image
    imgG = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    #mBlur = cv.medianBlur(imgG, 5)
    rowz = imgG.shape[0]
    # ret, thresh = cv.threshold(imgG, 127, 255, cv.THRESH_BINARY);
    img3 = cv.medianBlur(img, 5)
    imgG3 = cv.cvtColor(img3, cv.COLOR_BGR2GRAY)
    rows = imgG.shape[0]
    circlesInner = cv.HoughCircles(imgG3, cv.HOUGH_GRADIENT, 1, rowz / 4, param1=100, param2=30, minRadius=100,
                                   maxRadius=610)
    circlesOuter = cv.HoughCircles(imgG3, cv.HOUGH_GRADIENT, 1, rowz / 4, param1=100, param2=30, minRadius=300,
                                   maxRadius=610)
    whiteImage = np.zeros(img.shape, dtype=img.dtype)
    # print(circlesInner);
    # print(circlesOuter);
    Center += [circlesInner[0][0][0], circlesInner[0][0][1]]
    outerRadius = int(round(circlesOuter[0][0][2]))
    innerRadius = int(round(circlesInner[0][0][2]))
    # cv.circle(whiteImage,(512-1,512),innerRadius+30,(255,255,255) ,outerRadius-innerRadius-15)
    cv.circle(whiteImage, (512 - 1, 512), round((outerRadius + innerRadius) / 2), (255, 255, 255), 80)
    final = cv.bitwise_and(img, whiteImage)
    final = cv.cvtColor(final, cv.COLOR_BGR2GRAY)
    ret2, thresh2 = cv.threshold(final, 250, 255, cv.THRESH_BINARY);
    sector_image=thresh2
    # cv.imshow("window", sector_image)
    # cv.waitKey(0);
    return sector_image




    
####################################################################
## The main program which provides read in input of one image at a
## time to process function in which you will code your generalized
## output computing code
## Do not modify this code!!!
####################################################################
def main():
    ################################################################
    ## variable declarations
    ################################################################
    i = 1
    ## Reading 1 image at a time from the Images folder
    for image_name in os.listdir(images_folder_path):
        ## verifying name of image
        print(image_name)
        ## reading in image 
        ip_image = cv.imread(images_folder_path+"/"+image_name)
        ## verifying image has content
        print(ip_image.shape)
        ## passing read in image to process function
        sector_image = process(ip_image)
        ## saving the output in  an image of said name in the Generated folder
        cv.imwrite(generated_folder_path+"/"+"image_"+str(i)+"_fill_in.png", sector_image)
        i+=1


    

############################################################################################
## main function
############################################################################################
if __name__ == '__main__':
    main()
